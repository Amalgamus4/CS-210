#ifndef GROCERYLIST_H
#define GROCERYLIST_H

class GroceryList {
public:
	void PrintAllItems();
	void PrintHistogram();
	void PrintSingleItem();
	GroceryList(map<string, int> groceryList);
private:
	map<string, int> groceryList;
	string itemToSearch;
};

#endif