/*
Author - Ryan Ward
Date - 20 October 2024
Purpose - This program reads in a list of grocery items and creates
		  a map of the items and their quantities. The map is then
		  backed up to a .dat file, and the user has the option of
		  looking up an individual item, printing all items and their
		  quantities, or printing a histogram of all items.
*/

#include <iostream>
#include <map>
#include <string>
#include <fstream>
using namespace std;

#include "GroceryList.h"

void displayMenu();
int openFileForReading(ifstream& inputFS);
void readItemsFromFile(ifstream& inputFS, map<string, int>& todaysItems);
void openFileForWriting(ofstream& outputFS);
void writeBackupFile(ofstream& outputFS, map<string, int>& todaysItems);
int validateChoice(string userChoice);

const string INPUT_FILENAME = "groceries.txt"; // read file
const string OUTPUT_FILENAME = "frequency.dat"; // write file

int main() {
	// declare variables
	map<string, int> todaysItems;
	string userMenuChoice;
	int validatedChoice;
	ifstream inputFS;
	ofstream outputFS;
		
	openFileForReading(inputFS); // opens read file
	readItemsFromFile(inputFS, todaysItems); // reads items and updates map quantities
	openFileForWriting(outputFS); // opens write file
	writeBackupFile(outputFS, todaysItems); // writes all map items and quantities to file

	// create class to hold map and methods
	GroceryList todaysGroceryList(todaysItems);

	displayMenu();

	// get user input
	cin >> userMenuChoice;
	// validate user input
	validatedChoice = validateChoice(userMenuChoice);
	
	// use switch to determine action to take
	while (validatedChoice != 4) {
		switch (validatedChoice)
		{
		case 1:
			todaysGroceryList.PrintSingleItem();
			// user enters string, display item and quantity from map
			break;
		case 2:
			todaysGroceryList.PrintAllItems();
			// display all items and quantities
			break;
		case 3:
			todaysGroceryList.PrintHistogram();
			// display all items with historgram
			break;
		case 4:
			// exit program
			return 0;
			break;
		default:
			cout << endl << "Please enter a valid choice (1-4)" << endl;
			// display message for any value other than 1-4
			break;
		}
		displayMenu();
		// get and validate next user input
		cin >> userMenuChoice;
		validatedChoice = validateChoice(userMenuChoice);
	}
	return 0;
}

void displayMenu() {
	cout << endl << endl;
	cout << "************************************************" << endl;
	cout << "* Please choose a menu option:                 *" << endl;
	cout << "* 1 - Search for a grocery item                *" << endl;
	cout << "* 2 - Print a list of all items and quantities *" << endl;
	cout << "* 3 - Print a histogram of all items           *" << endl;
	cout << "* 4 - Exit program                             *" << endl;
	cout << "************************************************" << endl;
	cout << endl;
	cout << "Choice: ";
}

int openFileForReading(ifstream& inputFS) {
	// this function opens file for reading and reads in items and quantities to a map
	inputFS.open(INPUT_FILENAME);

	//verify file opened correctly
	if (!inputFS.is_open()) {
		cout << "Failed to open " << INPUT_FILENAME << " for input" << endl;
		return 1;
	}
	return 0;
}

void readItemsFromFile(ifstream& inputFS, map<string, int>& todaysItems) {
	// this function reads in all of the items from the txt file and adds them to a map
	
	string itemReadIn;
	// read in first item from file
	inputFS >> itemReadIn;

	while (!inputFS.fail()) {
		// add item to map if not already in map with value of 1
		if (todaysItems.count(itemReadIn) == 0) {
			todaysItems.emplace(itemReadIn, 1);
		}
		// if item already in list, increment map value by 1
		else if (todaysItems.count(itemReadIn) == 1) {
			todaysItems.at(itemReadIn)++;
		}
		// get next item in list
		inputFS >> itemReadIn;
	}

	// loop until eof
	// close file
	inputFS.close();
}

void openFileForWriting(ofstream& outputFS) {
	// open output file
	outputFS.open(OUTPUT_FILENAME);

	// verify file opened correctly
	if (!outputFS.is_open()) {
		cout << "Failed to open " << OUTPUT_FILENAME << " for output." << endl;
	}
}

void writeBackupFile(ofstream& outputFS, map<string, int>& todaysItems) {
	// this function loops through map and outputs each key/value pair to file
	for (const auto& pair : todaysItems) {
		outputFS << pair.first << " " << pair.second << endl;
	}

	// close output file
	outputFS.close();
}

int validateChoice(string userChoice) {
	// this function validates that userChoice is an integer
	bool choiceIsInteger = true;
	for (char character : userChoice) { // check if each character in userChoice is a digit
		if (!isdigit(character)) {
			choiceIsInteger = false; // if any character is not a digit, set bool to false
		}
	}
	if (choiceIsInteger) {
		return stoi(userChoice); // convert userChoice to integer and return value
	}
	else {
		return -1; // return -1 if userChoice is not an integer
	}
}