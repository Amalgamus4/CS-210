#include <iostream>
#include <iomanip>
#include <map>
using namespace std;

#include "GroceryList.h"

GroceryList::GroceryList(map<string, int> groceryList) {
	this->groceryList = groceryList;
}

void GroceryList::PrintSingleItem() {
	cout << endl << "Please enter an item name (case sensitive): ";
	cin >> itemToSearch;
	if (groceryList.count(itemToSearch) == 1) {
		cout << endl << itemToSearch << " " << groceryList.at(itemToSearch) << endl;
	}
	else {
		cout << endl << "Item not found" << endl << endl;
	}
}

void GroceryList::PrintAllItems() {
	cout << endl;
	cout << "List of all items sold today" << endl << endl;
	for (const auto& pair : groceryList) {
		cout << pair.first << " " << pair.second << endl;
	}
}
void GroceryList::PrintHistogram() {
	cout << endl << "Historgram of all items sold today" << endl << endl;
	for (const auto& pair : groceryList) {
		cout << setw(20) << pair.first; 
		for (int i = 0; i < pair.second; ++i) {
			cout << "*";
		}
		cout << endl;
	}
	cout << endl;
}